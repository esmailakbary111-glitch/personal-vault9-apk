export type VaultErrorCode =
  | 'VAULT_EXISTS'
  | 'VAULT_MISSING'
  | 'LOCKED'
  | 'WRONG_PASSWORD'
  | 'WEAK_PASSWORD'
  | 'ITEM_NOT_FOUND'
  | 'VALIDATION_FAILED'
  | 'STORAGE_FAILED'
  | 'BACKUP_INVALID'
  | 'BACKUP_UNSUPPORTED_VERSION'
  | 'BACKUP_INTEGRITY_FAILED'
  | 'BACKUP_WRONG_PASSWORD'
  | 'RESTORE_FAILED'
  | 'FILE_TOO_LARGE'
  | 'UNSUPPORTED_MIGRATION';

/** Errors carry a stable code; user-facing copy is resolved by the i18n layer. */
export class VaultError extends Error {
  readonly code: VaultErrorCode;
  readonly detail?: string;
  constructor(code: VaultErrorCode, detail?: string) {
    super(detail ? `${code}: ${detail}` : code);
    this.name = 'VaultError';
    this.code = code;
    this.detail = detail;
  }
}

export function isVaultError(e: unknown): e is VaultError {
  return e instanceof VaultError;
}
