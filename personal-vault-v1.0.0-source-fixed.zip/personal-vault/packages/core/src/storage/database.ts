import { VaultError } from '../domain/errors.ts';
import { DB_NAME, DB_VERSION, applyMigrations } from './schema.ts';

export interface OpenOptions {
  readonly name?: string;
  readonly version?: number;
  readonly factory?: IDBFactory;
  readonly onBlocked?: () => void;
  /** Called when another tab upgrades the DB and this connection must close. */
  readonly onVersionChange?: () => void;
}

export function openDatabase(options: OpenOptions = {}): Promise<IDBDatabase> {
  const factory = options.factory ?? globalThis.indexedDB;
  if (!factory) throw new VaultError('STORAGE_FAILED', 'IndexedDB unavailable in this runtime');
  const name = options.name ?? DB_NAME;
  const version = options.version ?? DB_VERSION;

  return new Promise((resolve, reject) => {
    const request = factory.open(name, version);

    request.onupgradeneeded = (event) => {
      const db = request.result;
      const tx = request.transaction;
      if (!tx) {
        reject(new VaultError('STORAGE_FAILED', 'missing upgrade transaction'));
        return;
      }
      try {
        applyMigrations(db, tx, event.oldVersion, event.newVersion ?? version);
      } catch (error) {
        tx.abort();
        reject(new VaultError('UNSUPPORTED_MIGRATION', (error as Error).message));
      }
    };

    request.onblocked = () => options.onBlocked?.();

    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => {
        options.onVersionChange?.();
        db.close();
      };
      resolve(db);
    };

    request.onerror = () => reject(new VaultError('STORAGE_FAILED', request.error?.name));
  });
}

export function deleteDatabase(name = DB_NAME, factory: IDBFactory = globalThis.indexedDB): Promise<void> {
  return new Promise((resolve, reject) => {
    const req = factory.deleteDatabase(name);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(new VaultError('STORAGE_FAILED', 'deleteDatabase failed'));
  });
}
