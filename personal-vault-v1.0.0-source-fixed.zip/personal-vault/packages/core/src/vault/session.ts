import type { Settings } from '../domain/types.ts';

/**
 * Holds the unlocked DEK and the auto-lock timer.
 *
 * The DEK is a non-extractable CryptoKey: we drop our only reference on lock
 * so the key object becomes unreachable. See docs/SECURITY.md for the honest
 * limits of "clearing memory" in JavaScript.
 */
export type LockReason = 'manual' | 'timeout' | 'background' | 'startup' | 'error';

export interface SessionListener {
  (event: { unlocked: boolean; reason?: LockReason }): void;
}

export interface SessionOptions {
  now?: () => number;
  setTimer?: (fn: () => void, ms: number) => unknown;
  clearTimer?: (handle: unknown) => void;
}

export class Session {
  private dek: CryptoKey | null = null;
  private timer: unknown = null;
  private autoLockMs: number;
  private lockOnBackground: boolean;
  private lastActivityAt = 0;
  private unlockedAt: number | null = null;
  private readonly listeners = new Set<SessionListener>();
  private readonly now: () => number;
  private readonly setTimer: (fn: () => void, ms: number) => unknown;
  private readonly clearTimer: (handle: unknown) => void;

  constructor(settings: Pick<Settings, 'autoLockMs' | 'lockOnBackground'>, options: SessionOptions = {}) {
    this.autoLockMs = settings.autoLockMs;
    this.lockOnBackground = settings.lockOnBackground;
    this.now = options.now ?? (() => Date.now());
    this.setTimer = options.setTimer ?? ((fn, ms) => setTimeout(fn, ms));
    this.clearTimer = options.clearTimer ?? ((handle) => clearTimeout(handle as never));
  }

  get isUnlocked(): boolean {
    return this.dek !== null;
  }

  get unlockedSince(): number | null {
    return this.unlockedAt;
  }

  subscribe(listener: SessionListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /** Throws instead of returning null so callers cannot forget the check. */
  requireKey(): CryptoKey {
    if (!this.dek) throw new Error('LOCKED');
    return this.dek;
  }

  open(dek: CryptoKey): void {
    this.dek = dek;
    this.unlockedAt = this.now();
    this.touch();
    this.emit({ unlocked: true });
  }

  /** Extends the auto-lock window. Called on real user interaction only. */
  touch(): void {
    if (!this.dek) return;
    this.lastActivityAt = this.now();
    this.arm();
  }

  configure(settings: Pick<Settings, 'autoLockMs' | 'lockOnBackground'>): void {
    this.autoLockMs = settings.autoLockMs;
    this.lockOnBackground = settings.lockOnBackground;
    if (this.dek) this.arm();
  }

  lock(reason: LockReason = 'manual'): void {
    this.disarm();
    this.dek = null;
    this.unlockedAt = null;
    this.emit({ unlocked: false, reason });
  }

  /** Called by the shells when the window/app is backgrounded. */
  handleAppHidden(): void {
    if (!this.dek) return;
    if (this.lockOnBackground || this.autoLockMs === 0) this.lock('background');
  }

  /**
   * Called when the app becomes visible again. Wall-clock is re-checked because
   * background timers are throttled or frozen on mobile.
   */
  handleAppVisible(): void {
    if (!this.dek) return;
    if (this.autoLockMs > 0 && this.now() - this.lastActivityAt >= this.autoLockMs) {
      this.lock('timeout');
      return;
    }
    this.arm();
  }

  private arm(): void {
    this.disarm();
    if (!this.dek) return;
    if (this.autoLockMs === 0) {
      // "Immediately" means: locked as soon as the app is not in active use.
      return;
    }
    this.timer = this.setTimer(() => {
      if (this.now() - this.lastActivityAt >= this.autoLockMs) this.lock('timeout');
      else this.arm();
    }, this.autoLockMs);
  }

  private disarm(): void {
    if (this.timer !== null) {
      this.clearTimer(this.timer);
      this.timer = null;
    }
  }

  private emit(event: { unlocked: boolean; reason?: LockReason }): void {
    for (const listener of this.listeners) listener(event);
  }
}
