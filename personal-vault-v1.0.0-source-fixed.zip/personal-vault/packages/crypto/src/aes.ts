import { VaultCryptoError } from './errors.ts';
import { fromBase64, toBase64 } from './bytes.ts';
import { randomBytes } from './random.ts';
import { subtle } from './subtle.ts';

export const CIPHER = 'AES-GCM-256' as const;
export const IV_BYTES = 12; // 96-bit nonce, the size AES-GCM is specified for
export const TAG_BITS = 128;

/**
 * Serializable ciphertext envelope. `aad` is stored so a reader knows which
 * context string to bind; it is authenticated, not secret.
 */
export interface Envelope {
  readonly v: 1;
  readonly cipher: typeof CIPHER;
  /** base64 nonce */
  readonly iv: string;
  /** base64 ciphertext incl. GCM tag */
  readonly ct: string;
  readonly aad?: string;
}

function assertEnvelope(env: Envelope): void {
  if (!env || env.v !== 1 || env.cipher !== CIPHER) throw new VaultCryptoError('UNSUPPORTED_CIPHER');
  if (typeof env.iv !== 'string' || typeof env.ct !== 'string') throw new VaultCryptoError('DATA_TAMPERED');
}

export async function encryptBytes(
  key: CryptoKey,
  plaintext: Uint8Array,
  aad?: string,
): Promise<Envelope> {
  const iv = randomBytes(IV_BYTES);
  const params: AesGcmParams = { name: 'AES-GCM', iv, tagLength: TAG_BITS };
  if (aad) params.additionalData = new TextEncoder().encode(aad);
  const ct = await subtle().encrypt(params, key, plaintext);
  const env: Envelope = { v: 1, cipher: CIPHER, iv: toBase64(iv), ct: toBase64(new Uint8Array(ct)) };
  return aad ? { ...env, aad } : env;
}

export async function decryptBytes(
  key: CryptoKey,
  env: Envelope,
  expectedAad?: string,
): Promise<Uint8Array> {
  assertEnvelope(env);
  const aad = expectedAad ?? env.aad;
  if (expectedAad && env.aad && env.aad !== expectedAad) {
    // The envelope was moved out of the context it was written for.
    throw new VaultCryptoError('DATA_TAMPERED');
  }
  const params: AesGcmParams = { name: 'AES-GCM', iv: fromBase64(env.iv), tagLength: TAG_BITS };
  if (aad) params.additionalData = new TextEncoder().encode(aad);
  try {
    const pt = await subtle().decrypt(params, key, fromBase64(env.ct));
    return new Uint8Array(pt);
  } catch {
    // GCM tag mismatch: wrong key or modified bytes. We cannot tell which.
    throw new VaultCryptoError('DATA_TAMPERED');
  }
}

export async function encryptJson(key: CryptoKey, value: unknown, aad?: string): Promise<Envelope> {
  const bytes = new TextEncoder().encode(JSON.stringify(value));
  try {
    return await encryptBytes(key, bytes, aad);
  } finally {
    bytes.fill(0);
  }
}

export async function decryptJson<T>(key: CryptoKey, env: Envelope, aad?: string): Promise<T> {
  const bytes = await decryptBytes(key, env, aad);
  try {
    return JSON.parse(new TextDecoder().decode(bytes)) as T;
  } finally {
    bytes.fill(0);
  }
}
