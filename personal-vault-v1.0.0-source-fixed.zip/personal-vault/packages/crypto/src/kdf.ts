import { VaultCryptoError } from './errors.ts';
import { randomBytes } from './random.ts';
import { fromBase64, toBase64, utf8Encode, wipe } from './bytes.ts';
import { subtle } from './subtle.ts';

export const KDF_ALGORITHM = 'PBKDF2-SHA256' as const;

/**
 * Chosen after evaluating the alternatives:
 *  - Argon2id is stronger per CPU cycle but needs WASM, which adds a binary
 *    asset to the extension bundle and a second code path in the Android
 *    WebView. Not available in Web Crypto.
 *  - PBKDF2-SHA256 is native everywhere we ship (browser, MV3 worker,
 *    Android WebView) with zero bundled binaries, which keeps the vault fully
 *    offline and reviewable.
 * We therefore use PBKDF2-SHA256 with a high iteration count as the floor.
 */
export const MIN_ITERATIONS = 600_000;
export const DEFAULT_ITERATIONS = 600_000;
export const SALT_BYTES = 16;

export interface KdfParams {
  readonly algorithm: typeof KDF_ALGORITHM;
  readonly iterations: number;
  /** base64 */
  readonly salt: string;
}

export function createKdfParams(iterations: number = DEFAULT_ITERATIONS): KdfParams {
  if (iterations < MIN_ITERATIONS) {
    throw new VaultCryptoError('UNSUPPORTED_KDF', 'iteration count below policy floor');
  }
  return { algorithm: KDF_ALGORITHM, iterations, salt: toBase64(randomBytes(SALT_BYTES)) };
}

export function assertKdfParams(params: KdfParams): void {
  if (params?.algorithm !== KDF_ALGORITHM) throw new VaultCryptoError('UNSUPPORTED_KDF');
  if (!Number.isInteger(params.iterations) || params.iterations < MIN_ITERATIONS) {
    throw new VaultCryptoError('UNSUPPORTED_KDF');
  }
  if (typeof params.salt !== 'string' || params.salt.length < 16) {
    throw new VaultCryptoError('UNSUPPORTED_KDF');
  }
}

/**
 * Derives the Key Encryption Key (KEK) from the master password.
 * The KEK only ever wraps/unwraps the DEK: it never touches user data.
 * The returned key is non-extractable, so the raw KEK bytes never exist in JS.
 */
export async function deriveKek(password: string, params: KdfParams): Promise<CryptoKey> {
  assertKdfParams(params);
  const passwordBytes = utf8Encode(password.normalize('NFKC'));
  try {
    const base = await subtle().importKey('raw', passwordBytes, 'PBKDF2', false, ['deriveKey']);
    return await subtle().deriveKey(
      {
        name: 'PBKDF2',
        hash: 'SHA-256',
        salt: fromBase64(params.salt),
        iterations: params.iterations,
      },
      base,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt'],
    );
  } finally {
    wipe(passwordBytes);
  }
}

export interface PasswordStrength {
  readonly score: 0 | 1 | 2 | 3 | 4;
  readonly acceptable: boolean;
  readonly issues: string[];
}

/** Local-only heuristic. No password ever leaves the device to be scored. */
export function assessPassword(password: string): PasswordStrength {
  const issues: string[] = [];
  if (password.length < 10) issues.push('length');
  if (!/[a-z]/.test(password) || !/[A-Z]/.test(password)) issues.push('case');
  if (!/[0-9]/.test(password)) issues.push('digit');
  if (!/[^A-Za-z0-9]/.test(password)) issues.push('symbol');
  if (/^(.)\1+$/.test(password)) issues.push('repetition');
  const raw = 4 - Math.min(4, issues.length);
  const score = (password.length >= 16 && issues.length === 0 ? 4 : raw) as PasswordStrength['score'];
  return { score, acceptable: password.length >= 10 && issues.length <= 1, issues };
}
